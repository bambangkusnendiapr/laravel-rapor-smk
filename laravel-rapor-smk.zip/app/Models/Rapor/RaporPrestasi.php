<?php

namespace App\Models\Rapor;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RaporPrestasi extends Model
{
    use HasFactory;
}
