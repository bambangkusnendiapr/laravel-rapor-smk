<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/css/reset.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/css/style.css')); ?>">
    <title>Rapor UMUM</title>
    <style>
        body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            background-color: #FAFAFA;
            font: 12pt "Tahoma";
        }
        
        * {
            box-sizing: border-box;
            -moz-box-sizing: border-box;
        }
        
        @media  print {
            body {
                width: 40cm;
                height: 29.7cm;
                margin: 30mm 45mm 30mm -52mm;
            }
        }
    </style>
</head>

<body>

    <div class="page">


        <div class="container my-3">
            <h5 class="d-flex justify-content-center mb-4">PENCAPAIAN KOMPETENSI PESERTA DIDIK</h5>
            <div class="d-flex justify-content-between">
                <div class="d-flex">
                    <table>
                        <tbody>
                            <tr>
                                <td>Nama Sekolah</td>
                                <td>&nbsp;&nbsp;&nbsp;:</td>
                                <td>SMK PERSIS 02 KOTA BANDUNG</td>
                            </tr>
                            <tr>
                                <td>Alamat</td>
                                <td>&nbsp;&nbsp;&nbsp;:</td>
                                <td>Jl Sukamulya dalam I RT.06 Rw.09 Kel. Sukaasih Kec. Bojongloa Kaler</td>
                            </tr>
                            <tr>
                                <td>Nama</td>
                                <td>&nbsp;&nbsp;&nbsp;:</td>
                                <td><?php echo e($rapor->student->user->name); ?></td>
                            </tr>
                            <tr>
                                <td>No Induk</td>
                                <td>&nbsp;&nbsp;&nbsp;:</td>
                                <td><?php echo e($rapor->student->no_induk); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex">
                    <table>
                        <tbody>
                            <tr>
                                <td>NISN</td>
                                <td>&nbsp;&nbsp;&nbsp;:</td>
                                <td><?php echo e($rapor->student->nis); ?></td>
                            </tr>
                            <tr>
                                <td>Kelas</td>
                                <td>&nbsp;&nbsp;&nbsp;:</td>
                                <td><?php echo e($rapor->kelas); ?>/<?php echo e($rapor->student->major->jurusan); ?></td>
                            </tr>
                            <tr>
                                <td>Semester</td>
                                <td>&nbsp;&nbsp;&nbsp;:</td>
                                <td><?php echo e($rapor->semester->nama); ?></td>
                            </tr>
                            <tr>
                                <td>Tahun Pelajaran</td>
                                <td>&nbsp;&nbsp;&nbsp;:</td>
                                <td><?php echo e($rapor->semester->tahun); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <hr>
        </div>

        <!-- sikap -->
        <div class="container mb-2">
            <h5>A. Sikap</h5>
            <div class="flex flex-column">
                <div class="sikap mb-2">
                    <h6>&nbsp;&nbsp;1. Sikap Spiritual</h6>
                    <div class="border">
                        <p>Deskripsi:</p>
                        <p><?php echo e($rapor->spiritual); ?></p>
                    </div>
                </div>
                <div class="sosial">
                    <h6>&nbsp;&nbsp;2. Sikap Sosial</h6>
                    <div class="border">
                        <p>Deskripsi:</p>
                        <p><?php echo e($rapor->sosial); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- pengetahuan dan keterampilan -->
        <div class="container">
            <h5>B. Pengetahuan dan Keterampilan</h5>
            <h6>&nbsp;&nbsp;Ketuntasan Belajar Minimal : 75</h6>
            <div class="">
                <table class="table table-bordered ">
                    <thead>
                        <tr>
                            <th rowspan="2">No</th>
                            <th rowspan="2">Mata Pelajaran</th>

                            <th colspan="3">Pengetahuan</th>
                            <th colspan="3">Keterampilan</th>
                        </tr>
                        <tr>
                            <th>nilai</th>
                            <th>predikat</th>
                            <th>deskripsi</th>

                            <th>nilai</th>
                            <th>predikat</th>
                            <th>deskripsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $kelompok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th colspan="8"><?php echo e($k->nama); ?></th>
                        </tr>
                        <?php $__currentLoopData = $mapel->where('group_id', $k->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td>
                                <?php echo e($m->nama); ?><br>
                                <?php $__currentLoopData = $pelajaran_guru->where('lesson_id', $m->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-primary"><?php echo e($pg->teacher->user->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <?php $__empty_1 = true; $__currentLoopData = $nilai->where('lesson_id', $m->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <td><?php echo e($value->pengetahuan_nilai); ?></td>
                            <td><?php echo e($value->pengetahuan_predikat); ?></td>
                            <td><?php echo e($value->pengetahuan_deskripsi); ?></td>
                            <td><?php echo e($value->keterampilan_nilai); ?></td>
                            <td><?php echo e($value->keterampilan_predikat); ?></td>
                            <td><?php echo e($value->keterampilan_deskripsi); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th colspan="2">Jumlah</th>
                            <th><?php echo e($nilai->sum('pengetahuan_nilai') +  $nilai->sum('keterampilan_nilai')); ?></th>
                            <td colspan="5"></td>
                        </tr>
                        <tr>
                            <th colspan="2">Rata-rata</th>
                            <th><?php if(($nilai->sum('pengetahuan_nilai') +  $nilai->sum('keterampilan_nilai')) != 0): ?>
                                <?php echo e(number_format((float)($nilai->sum('pengetahuan_nilai') +  $nilai->sum('keterampilan_nilai')) / ($nilai->count() * 2), 2, ',', '')); ?>

                                <?php endif; ?></th>
                            <td colspan="5"></td>
                        </tr>
                        <tr>
                            <th colspan="2">Peringkat ke</th>
                            <td colspan="6"><b></b> dari Siswa</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ekstrakulikuler -->
        <div class="container">
            <h5>C. Ekstra Kurikuler</h5>
            <table class='table table-bordered'>
                <thead>
                    <tr>
                        <th>Kegiatan Ekstra Kurikuler</th>
                        <th>Nilai</th>
                        <th>Keterangan dalam kegiatan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $rapor->raporeskul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eskul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($eskul->extracurricular->nama); ?></td>
                        <td><?php echo e($eskul->nilai); ?></td>
                        <td><?php echo e($eskul->ket); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- ketidakhadiran -->
        <div class="container">
            <h5>D. Ketidakhadiran</h5>
            <table class='table table-bordered'>
                <thead>
                    <tr>
                        <th colspan="3" class="text-center">Ketidakhadiran</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td width="2">1</td>
                        <td>Sakit</td>
                        <td><?php echo e($rapor->sakit); ?> Hari</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Izin</td>
                        <td><?php echo e($rapor->izin); ?> Hari</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Tanpa Keterangan</td>
                        <td><?php echo e($rapor->alpa); ?> Hari</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- prestasi -->
        <div class="container">
            <h5>E. Prestasi</h5>
            <table class='table table-bordered'>
                <thead>
                    <tr>
                        <th class="text-center">No</th>
                        <th class="text-center">Jenis Prestasi</th>
                        <th class="text-center">Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $rapor->raporprestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td width="2"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($prestasi->prestasi); ?></td>
                        <td><?php echo e($prestasi->ket); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- catatan wali kelas -->
        <div class="container mb-2">
            <h5>F. Catatan Wali Kelas</h5>
            <div class="catatan">
                <p><?php echo e($rapor->catatan); ?></p>
            </div>
        </div>

        <!-- orangtua -->
        <div class="container mb-4">
            <h5>G. Tanggapan Orang tua/wali</h5>
            <div class="catatan">
                <p><?php echo e($rapor->catatan_ortu); ?></p>
            </div>
        </div>

        <!-- ttd -->
        <div class="container">
            <div class="d-flex justify-content-between">
                <div class="orangtua">
                    <h6>Orang Tua/Wali</h6>
                    <br><br><br><br><br>
                    <p><?php echo e($rapor->student->ortu->user->name); ?></p>
                </div>
                <div class="walikelas">
                    <h6>Wali Kelas</h6>
                    <br><br><br><br><br>
                    <b><p><?php echo e($wali_kelas->teacher->user->name); ?></p></b>
                </div>
                <div class="kepsek">
                    <h6>Bandung, <?php if($rapor->tanggal != null): ?> <?php echo e($rapor->tanggal->format('d')); ?> <?php echo e($bulan); ?> <?php echo e($rapor->tanggal->format('Y')); ?> <?php endif; ?></h6>
                    <h6>Mengetahui</h6>
                    <h6>Kepala Sekolah,</h6>
                    <br><br><br><br>
                    <b><p>H. Jejen Jaenudin, M.Pd.I</p></b>
                </div>
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH C:\Users\ASUS\Documents\Aplikasi\laravel-rapor-smk\resources\views/admin/rapor/print.blade.php ENDPATH**/ ?>