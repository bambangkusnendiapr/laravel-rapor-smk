<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="#" class="brand-link">
    <img src="<?php echo e(asset('admin/dist/img/logo.png')); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text font-weight-light">SMK Persis</span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user (optional) -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <!-- <div class="image">
        <img src="<?php echo e(asset('admin/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
      </div> -->
      <div class="info">
        <a href="<?php echo e(route('profile')); ?>" class="d-block"><?php echo e(Auth::user()->name); ?> <span class="right badge badge-primary"><?php echo e(Auth::user()->roles->first()->display_name); ?></span></a>
      </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
              with font-awesome or any other icon font library -->
        <li class="nav-header">MAIN MENU</li>
        <li class="nav-item">
          <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo $__env->yieldContent('dashboard'); ?>">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>
              Dashboard
            </p>
          </a>
        </li>
        <?php if (app('laratrust')->hasRole('superadmin')) : ?>
        <li class="nav-item">
          <a href="<?php echo e(route('bayar')); ?>" class="nav-link <?php echo $__env->yieldContent('bayar'); ?>">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>
              Bayar
            </p>
          </a>
        </li>
        <?php endif; // app('laratrust')->hasRole ?>
        <?php if (app('laratrust')->hasRole('superadmin|wali_kelas')) : ?>
        <li class="nav-header">DATA MASTER</li>
        <li class="nav-item <?php echo $__env->yieldContent('wali'); ?>">
          <a href="#" class="nav-link <?php echo $__env->yieldContent('kelas'); ?>">
            <i class="nav-icon fab fa-buffer"></i>
            <p>
              Kelola Data Wali Kelas
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('wali.kelas')); ?>" class="nav-link <?php echo $__env->yieldContent('wali-kelas'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Data Wali Kelas</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('pelajaran')); ?>" class="nav-link <?php echo $__env->yieldContent('pelajaran'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Bank Pelajaran</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('semester')); ?>" class="nav-link <?php echo $__env->yieldContent('semester'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Semester</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('jurusan')); ?>" class="nav-link <?php echo $__env->yieldContent('jurusan'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Jurusan</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('kelompok')); ?>" class="nav-link <?php echo $__env->yieldContent('kelompok'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Kelompok Pelajaran</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('ekstrakurikuler')); ?>" class="nav-link <?php echo $__env->yieldContent('ekstrakurikuler'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Ekstrakurikuler</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('jabatan')); ?>" class="nav-link <?php echo $__env->yieldContent('jabatan'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Jabatan</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item <?php echo $__env->yieldContent('data-guru'); ?>">
          <a href="#" class="nav-link <?php echo $__env->yieldContent('data_guru'); ?>">
            <i class="nav-icon fab fa-buffer"></i>
            <p>
              Kelola Data Guru
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('guru')); ?>" class="nav-link <?php echo $__env->yieldContent('guru'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Data Guru</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('pelajaran.guru')); ?>" class="nav-link <?php echo $__env->yieldContent('pelajaran-guru'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Mata Pelajaran</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item <?php echo $__env->yieldContent('data-siswa'); ?>">
          <a href="#" class="nav-link <?php echo $__env->yieldContent('data_siswa'); ?>">
            <i class="nav-icon fab fa-buffer"></i>
            <p>
              Kelola Data Siswa
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('students.index')); ?>" class="nav-link <?php echo $__env->yieldContent('student'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Data Siswa</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item <?php echo $__env->yieldContent('orang'); ?>">
          <a href="#" class="nav-link <?php echo $__env->yieldContent('tua'); ?>">
            <i class="nav-icon fab fa-buffer"></i>
            <p>
              Kelola Data Orang Tua
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('ortu')); ?>" class="nav-link <?php echo $__env->yieldContent('ortu'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Data Orang Tua</p>
              </a>
            </li>
          </ul>
        </li>
        <?php endif; // app('laratrust')->hasRole ?>
        <li class="nav-header">RAPOR</li>
        <li class="nav-item <?php echo $__env->yieldContent('nilai-rapor'); ?>">
          <a href="#" class="nav-link <?php echo $__env->yieldContent('nilai_rapor'); ?>">
            <i class="nav-icon fab fa-buffer"></i>
            <p>
              Penilaian Rapor
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('rapor')); ?>" class="nav-link <?php echo $__env->yieldContent('rapor'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Data Rapor</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('rapor.nilai')); ?>" class="nav-link <?php echo $__env->yieldContent('rapor-nilai'); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Penilaian</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-header">KELUAR</li>
        <li class="nav-item">
          <a href="<?php echo e(route('logout')); ?>" class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="nav-icon fas fa-sign-out-alt"></i>
            <p>
              Logout
            </p>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none"><?php echo csrf_field(); ?></form>
          </a>
        </li>
      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside><?php /**PATH C:\Users\ASUS\Documents\Aplikasi\laravel-rapor-smk\resources\views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>