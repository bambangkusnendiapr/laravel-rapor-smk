<?php $__env->startSection('title', 'Nilai Rapor'); ?>
<?php $__env->startSection('nilai-rapor', 'menu-open'); ?>
<?php $__env->startSection('nilai_rapor', 'active'); ?>
<?php $__env->startSection('rapor', 'active'); ?>
<div>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Nilai Rapor</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Admin</a></li>
              <li class="breadcrumb-item"><a href="#">Penilaian Rapor</a></li>
              <li class="breadcrumb-item active">Nilai Rapor</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">

            <!-- Rapor untuk semua -->
            <!-- Default box -->
            <div class="card">
              <?php if (app('laratrust')->hasRole('superadmin|wali_kelas')) : ?>
              <div class="card-header">
                <h3 class="card-title"><button wire:click.prevent="addNew" type="button" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah Data</button> &nbsp; Rapor Siswa</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <?php endif; // app('laratrust')->hasRole ?>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-4">
                      <div class="form-group">
                          <select wire:model="paginate" class="form-control form-control-sm">
                              <option value="10">10 data per halaman</option>
                              <option value="15">15 data per halaman</option>
                              <option value="20">20 data per halaman</option>
                              <option value="30">30 data per halaman</option>
                              <option value="50">50 data per halaman</option>
                          </select>
                      </div>
                  </div>

                  <div class="col-md-4 offset-md-4">
                      <div class="form-group">
                          <div class="input-group input-group-sm">
                              <input wire:model="search" type="text" class="form-control form-control-sm" placeholder="Cari nama...">
                              <div class="input-group-append">
                                  <span class="input-group-text"><i class="fas fa-search"></i></span>
                              </div>
                          </div>
                          <!-- <input  type="text" class="form-control form-control-sm w-100" placeholder="Cari Nama"> -->
                      </div>
                  </div>
                </div>

                <div class="table-responsive-sm">
                  <table class="table table-sm table-striped mt-1">
                      <thead>
                          <tr class="text-center">
                              <th>#</th>
                              <?php if (app('laratrust')->hasRole('superadmin|wali_kelas|siswa|orang_tua')) : ?>
                              <th>Catatan Orang Tua</th>
                              <?php endif; // app('laratrust')->hasRole ?>
                              <th>Nama Siswa</th>
                              <th>Semester</th>
                              <th>Tahun Ajaran</th>
                              <th>Kelas</th>
                              <th>Jurusan</th>
                              <?php if (app('laratrust')->hasRole('superadmin|guru')) : ?>
                              <th>Penilaian Pelajaran</th>
                              <th>Penilaian Pesantren</th>
                              <?php endif; // app('laratrust')->hasRole ?>
                              <!-- <th>Penilaian & Catatan</th> -->
                              <?php if (app('laratrust')->hasRole('superadmin|wali_kelas|siswa|orang_tua')) : ?>
                              <th>Penilaian Kepesantrenan</th>
                              <th>Aksi</th>
                              <?php endif; // app('laratrust')->hasRole ?>
                          </tr>
                      </thead>
                      <tbody>
                          <?php if($rapor->isEmpty()): ?>
                              <tr>
                                      <td colspan="11" class="text-center font-italic text-danger"><h5>-- Data Tidak Ditemukan --</h5></td>
                              </tr>
                          <?php else: ?>
                              <?php $__currentLoopData = $rapor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($rapor->firstItem() + $key); ?></td>
                                    <?php if (app('laratrust')->hasRole('superadmin|wali_kelas|siswa|orang_tua')) : ?>
                                    <td><button class="btn btn-danger" wire:click.prevent="catatan_ortu(<?php echo e($data->id); ?>)">Catatan Orang Tua</button></td>
                                    <?php endif; // app('laratrust')->hasRole ?>
                                    <td class="text-center"><?php echo e($data->student->user->name); ?></td>
                                    <td class="text-center"><?php echo e($data->semester->nama); ?></td>
                                    <td class="text-center"><?php echo e($data->semester->tahun); ?></td>
                                    <td class="text-center"><?php echo e($data->kelas); ?></td>
                                    <td class="text-center"><?php echo e($data->student->major->jurusan); ?></td>
                                    <?php if (app('laratrust')->hasRole('superadmin|guru')) : ?>
                                    <td class="text-center"><a href="<?php echo e(route('penilaian', $data->id)); ?>" class="btn btn-primary">Nilai Pelajaran Umum</a></td>
                                    <td class="text-center"><a href="<?php echo e(route('penilaian.pesantren', $data->id)); ?>" class="btn btn-success">Nilai Pelajaran Pesantren</a></td>
                                    <?php endif; // app('laratrust')->hasRole ?>
                                    <!-- <td class="text-center"><button wire:click.prevent="lihat(<?php echo e($data->id); ?>)" class="btn btn-secondary">Lihat Penilaian & Catatan</button></td> -->
                                    <?php if (app('laratrust')->hasRole('superadmin|wali_kelas|siswa|orang_tua')) : ?>
                                    <td class="text-center">
                                      <div class="dropdown">
                                          <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
                                            Rapor Kepesantrenan
                                          </button>
                                          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="<?php echo e(route('rapor.pesantren', $data->id)); ?>">Rapor Kepesantrenan</a>
                                            <button class="dropdown-item" wire:click.prevent="catatan_pesantren(<?php echo e($data->id); ?>)">Catatan, Pengembangan & Absensi</button>
                                            <a class="dropdown-item" href="<?php echo e(route('eskul.pesantren', $data->id)); ?>">Ekstrakurikuler</a>
                                            <?php if($data->semester->nama == 'Genap'): ?>
                                              <button class="dropdown-item" wire:click.prevent="kelulusan(<?php echo e($data->id); ?>)">Kelulusan</button>
                                            <?php endif; ?>
                                          </div>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                      <div class="btn-group">
                                        <div class="dropdown">
                                          <button class="btn btn-info dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
                                            Rapor
                                          </button>
                                          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="<?php echo e(route('penilaian.rapor', $data->id)); ?>">Pengetahuan & Keterampilan</a>
                                            <a class="dropdown-item" href="<?php echo e(route('eskul', $data->id)); ?>">Ekstrakurikuler</a>
                                            <a class="dropdown-item" href="<?php echo e(route('prestasi', $data->id)); ?>">Prestasi</a>
                                          </div>
                                        </div>
                                        <div class="btn-group">
                                            <button wire:click.prevent="edit(<?php echo e($data->id); ?>)" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></button>
                                            <?php if (app('laratrust')->hasRole('superadmin|wali_kelas')) : ?>
                                            <button wire:click.prevent="delete(<?php echo e($data->id); ?>)" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                                            <?php endif; // app('laratrust')->hasRole ?>
                                        </div>
                                      </div>
                                    </td>
                                    <?php endif; // app('laratrust')->hasRole ?>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                      </tbody>
                  </table>
                </div>

              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <div class="d-flex justify-content-center">
                  <?php echo e($rapor->links()); ?>

                </div>
              </div>
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->


            <!-- Rapor untuk wali kelas -->
            <?php if (app('laratrust')->hasRole('wali_kelas')) : ?>
              <!-- Default box -->
            <div class="card">
              <div class="card-header bg-primary">
                <h3 class="card-title">Penilaian Mata Pelajaran</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-4">
                      <div class="form-group">
                          <select wire:model="halaman" class="form-control form-control-sm">
                              <option value="10">10 data per halaman</option>
                              <option value="15">15 data per halaman</option>
                              <option value="20">20 data per halaman</option>
                              <option value="30">30 data per halaman</option>
                              <option value="50">50 data per halaman</option>
                          </select>
                      </div>
                  </div>

                  <div class="col-md-4 offset-md-4">
                      <div class="form-group">
                          <div class="input-group input-group-sm">
                              <input wire:model="cari" type="text" class="form-control form-control-sm" placeholder="Cari nama...">
                              <div class="input-group-append">
                                  <span class="input-group-text"><i class="fas fa-search"></i></span>
                              </div>
                          </div>
                          <!-- <input  type="text" class="form-control form-control-sm w-100" placeholder="Cari Nama"> -->
                      </div>
                  </div>
                </div>

                <div class="table-responsive-sm">
                  <table class="table table-sm table-striped mt-1">
                      <thead>
                          <tr class="text-center">
                              <th>#</th>
                              <th>Nama Siswa</th>
                              <th>Semester</th>
                              <th>Tahun Ajaran</th>
                              <th>Kelas</th>
                              <th>Jurusan</th>
                              <th>Penilaian Pelajaran</th>
                              <th>Penilaian Pesantren</th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php if($rapor_wali_kelas->isEmpty()): ?>
                              <tr>
                                      <td colspan="8" class="text-center font-italic text-danger"><h5>-- Data Tidak Ditemukan --</h5></td>
                              </tr>
                          <?php else: ?>
                              <?php $__currentLoopData = $rapor_wali_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($rapor_wali_kelas->firstItem() + $key); ?></td>
                                    <td class="text-center"><?php echo e($value->student->user->name); ?></td>
                                    <td class="text-center"><?php echo e($value->semester->nama); ?></td>
                                    <td class="text-center"><?php echo e($value->semester->tahun); ?></td>
                                    <td class="text-center"><?php echo e($value->kelas); ?></td>
                                    <td class="text-center"><?php echo e($value->student->major->jurusan); ?></td>
                                    <td class="text-center"><a href="<?php echo e(route('penilaian', $value->id)); ?>" class="btn btn-primary">Nilai Pelajaran Umum</a></td>
                                    <td class="text-center"><a href="<?php echo e(route('penilaian.pesantren', $value->id)); ?>" class="btn btn-success">Nilai Pelajaran Pesantren</a></td>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                      </tbody>
                  </table>
                </div>

              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <div class="d-flex justify-content-center">
                  <?php echo e($rapor_wali_kelas->links()); ?>

                </div>
              </div>
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->
            <?php endif; // app('laratrust')->hasRole ?>
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->

    <!-- Modal Tambah Data -->
  <div class="modal fade" id="form" wire:ignore.self>
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header bg-primary">
          <h4 class="modal-title">Form Tambah Data</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form wire:submit.prevent="createData">
          <div class="modal-body">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="tanggal">Tanggal Bagi Rapor</label>
                  <input wire:model.defer="state.tanggal" type="date" class="form-control <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="tanggal">
                  <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="semester">Semester - Tahun Ajaran</label>
                  <select wire:model.defer="state.semester" class="form-control <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="semester">
                    <option value="">--Pilih--</option>
                    <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?> - <?php echo e($data->tahun); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

              </div>

            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="kelas">Kelas</label>
                  <select wire:model.defer="state.kelas" class="form-control <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="kelas">
                    <option value="">--Pilih--</option>
                    <option value="X">X</option>
                    <option value="XI">XI</option>
                    <option value="XII">XII</option>
                  </select>
                  <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
  
              </div>              
  
              <div class="col-md-6">
                <div class="form-group">
                  <label for="siswa">Siswa</label>
                  <select wire:model.defer="state.siswa" class="form-control <?php $__errorArgs = ['siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="siswa">
                    <option value="">--Pilih--</option>
                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($data->id); ?>"><?php echo e($data->kelas); ?> - <?php echo e($data->major->jurusan); ?> - <?php echo e($data->user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php $__errorArgs = ['siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
            </div>  
            
            <hr>

            <div class="form-group">
              <label for="spiritual">Deskripsi Sikap Spiritual</label>
              <textarea wire:model.defer="state.spiritual" class="form-control <?php $__errorArgs = ['spiritual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="spiritual" placeholder="Deskripsi Sikap Spiritual"></textarea>
              <?php $__errorArgs = ['spiritual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
              <label for="sosial">Deskripsi Sikap Sosial</label>
              <textarea wire:model.defer="state.sosial" class="form-control <?php $__errorArgs = ['sosial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="sosial" placeholder="Deskripsi Sikap Sosial"></textarea>
              <?php $__errorArgs = ['sosial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
              <label for="catatan">Catatan Wali Kelas</label>
              <textarea wire:model.defer="state.catatan" class="form-control <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="catatan" placeholder="Catatan Wali Kelas"></textarea>
              <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <hr>

            <div class="row">
              <div class="col-md-3">
                <div class="form-group">
                  <label>Sakit</label>
                    <div class="input-group">
                        <input wire:model.defer="state.sakit" type="number" class="form-control <?php $__errorArgs = ['sakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                    <?php $__errorArgs = ['sakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Izin</label>
                    <div class="input-group">
                        <input wire:model.defer="state.izin" type="number" class="form-control <?php $__errorArgs = ['izin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                    <?php $__errorArgs = ['izin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Tanpa Keterangan</label>
                    <div class="input-group">
                        <input wire:model.defer="state.alpa" type="number" class="form-control <?php $__errorArgs = ['alpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                    <?php $__errorArgs = ['alpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
            </div>
            
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->

  <!-- Modal Edit Data -->
  <div class="modal fade" id="modal-edit" wire:ignore.self>
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header bg-warning">
          <h4 class="modal-title">Form Edit Data</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form wire:submit.prevent="updateData">
          <div class="modal-body">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="tanggal">Tanggal Bagi Rapor</label>
                  <input wire:model.defer="state.tanggal" type="date" class="form-control <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="tanggal">
                  <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="semester">Semester - Tahun Ajaran</label>
                  <select wire:model.defer="state.semester" class="form-control <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="semester">
                    <option value="">--Pilih--</option>
                    <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?> - <?php echo e($data->tahun); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

              </div>

            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="kelas">Kelas</label>
                  <select wire:model.defer="state.kelas" class="form-control <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="kelas">
                    <option value="">--Pilih--</option>
                    <option value="X">X</option>
                    <option value="XI">XI</option>
                    <option value="XII">XII</option>
                  </select>
                  <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
  
              </div>              
  
              <div class="col-md-6">
                <div class="form-group">
                  <label for="siswa">Siswa</label>
                  <select wire:model.defer="state.siswa" class="form-control <?php $__errorArgs = ['siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="siswa">
                    <option value="">--Pilih--</option>
                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($data->id); ?>"><?php echo e($data->kelas); ?> - <?php echo e($data->major->jurusan); ?> - <?php echo e($data->user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php $__errorArgs = ['siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
            </div>
                        
            <hr>

            <div class="form-group">
              <label for="spiritual">Deskripsi Sikap Spiritual</label>
              <textarea wire:model.defer="state.spiritual" <?php if (app('laratrust')->hasRole('siswa|orang_tua')) : ?> readonly <?php endif; // app('laratrust')->hasRole ?> class="form-control <?php $__errorArgs = ['spiritual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="spiritual" placeholder="Deskripsi Sikap Spiritual"></textarea>
              <?php $__errorArgs = ['spiritual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
              <label for="sosial">Deskripsi Sikap Sosial</label>
              <textarea wire:model.defer="state.sosial" <?php if (app('laratrust')->hasRole('siswa|orang_tua')) : ?> readonly <?php endif; // app('laratrust')->hasRole ?> class="form-control <?php $__errorArgs = ['sosial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="sosial" placeholder="Deskripsi Sikap Sosial"></textarea>
              <?php $__errorArgs = ['sosial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
              <label for="catatan">Catatan Wali Kelas</label>
              <textarea wire:model.defer="state.catatan" <?php if (app('laratrust')->hasRole('siswa|orang_tua')) : ?> readonly <?php endif; // app('laratrust')->hasRole ?> class="form-control <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="catatan" placeholder="Catatan Wali Kelas"></textarea>
              <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <hr>

            <div class="row">
              <div class="col-md-3">
                <div class="form-group">
                  <label>Sakit</label>
                    <div class="input-group">
                        <input wire:model.defer="state.sakit" <?php if (app('laratrust')->hasRole('siswa|orang_tua')) : ?> readonly <?php endif; // app('laratrust')->hasRole ?> type="number" class="form-control <?php $__errorArgs = ['sakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                    <?php $__errorArgs = ['sakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Izin</label>
                    <div class="input-group">
                        <input wire:model.defer="state.izin" <?php if (app('laratrust')->hasRole('siswa|orang_tua')) : ?> readonly <?php endif; // app('laratrust')->hasRole ?> type="number" class="form-control <?php $__errorArgs = ['izin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                    <?php $__errorArgs = ['izin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Tanpa Keterangan</label>
                    <div class="input-group">
                        <input wire:model.defer="state.alpa" <?php if (app('laratrust')->hasRole('siswa|orang_tua')) : ?> readonly <?php endif; // app('laratrust')->hasRole ?> type="number" class="form-control <?php $__errorArgs = ['alpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                    <?php $__errorArgs = ['alpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Jumlah</label>
                    <div class="input-group">
                        <input wire:model.defer="state.jumlah" readonly type="number" class="form-control"/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                </div>
              </div>
            </div>
            
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
            <?php if (app('laratrust')->hasRole('superadmin|wali_kelas')) : ?>
            <button type="submit" class="btn btn-warning">Edit</button>
            <?php endif; // app('laratrust')->hasRole ?>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->

  <!-- Modal Lihat Data -->
  <div class="modal fade" id="modal-lihat" wire:ignore.self>
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header bg-secondary">
          <h4 class="modal-title"><?php echo e($lihat_siswa); ?></h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form wire:submit.prevent="updateData">
          <div class="modal-body">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label>Semester - Tahun jaran</label>
                  <input type="text" class="form-control" readonly value="<?php echo e($lihat_semester); ?>">
                </div>
              </div>
              
              <div class="col-md-6">
                <label>Kelas - Jurusan</label>
                <input type="text" class="form-control" readonly value="<?php echo e($lihat_kelas); ?>">
              </div>
            </div>  
            
            <hr>

            <div class="form-group">
              <label for="spiritual">Deskripsi Sikap Spiritual</label>
              <textarea wire:model.defer="state.spiritual" readonly class="form-control <?php $__errorArgs = ['spiritual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="spiritual" placeholder="Deskripsi Sikap Spiritual"></textarea>
              <?php $__errorArgs = ['spiritual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
              <label for="sosial">Deskripsi Sikap Sosial</label>
              <textarea wire:model.defer="state.sosial" readonly class="form-control <?php $__errorArgs = ['sosial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="sosial" placeholder="Deskripsi Sikap Sosial"></textarea>
              <?php $__errorArgs = ['sosial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
              <label for="catatan">Catatan Wali Kelas</label>
              <textarea wire:model.defer="state.catatan" readonly class="form-control <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="catatan" placeholder="Catatan Wali Kelas"></textarea>
              <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="row">
              <div class="col-md-3">
                <div class="form-group">
                  <label>Sakit</label>
                    <div class="input-group">
                        <input wire:model.defer="state.sakit" readonly type="number" class="form-control <?php $__errorArgs = ['sakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                    <?php $__errorArgs = ['sakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Izin</label>
                    <div class="input-group">
                        <input wire:model.defer="state.izin" readonly type="number" class="form-control <?php $__errorArgs = ['izin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                    <?php $__errorArgs = ['izin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Tanpa Keterangan</label>
                    <div class="input-group">
                        <input wire:model.defer="state.alpa" readonly type="number" class="form-control <?php $__errorArgs = ['alpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                    <?php $__errorArgs = ['alpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Jumlah</label>
                    <div class="input-group">
                        <input wire:model.defer="state.jumlah" readonly type="number" class="form-control"/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                </div>
              </div>
            </div>
            
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->

  <!-- Modal Catatan Pesantren -->
  <div class="modal fade" id="modal-catatan-pesantren" wire:ignore.self>
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header bg-success">
          <h4 class="modal-title">Form Catatan Kepesantrenan</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form wire:submit.prevent="updateCatatanPesantren">
          <div class="modal-body">
            <div class="form-group">
              <label for="catatan_pesantren">Catatan Kepesantrenan</label>
              <textarea wire:model.defer="state.catatan_pesantren" <?php if (app('laratrust')->hasRole('siswa|orang_tua')) : ?> readonly <?php endif; // app('laratrust')->hasRole ?> required class="form-control <?php $__errorArgs = ['catatan_pesantren'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="catatan_pesantren" placeholder="Catatan Kepesantrenan"></textarea>
              <?php $__errorArgs = ['catatan_pesantren'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>Kelakuan</label>
                  <input wire:model.defer="state.kelakuan" <?php if (app('laratrust')->hasRole('siswa|orang_tua')) : ?> readonly <?php endif; // app('laratrust')->hasRole ?> required type="text" class="form-control <?php $__errorArgs = ['kelakuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Kelakuan">
                  <?php $__errorArgs = ['kelakuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>Disiplin</label>
                  <input wire:model.defer="state.disiplin" <?php if (app('laratrust')->hasRole('siswa|orang_tua')) : ?> readonly <?php endif; // app('laratrust')->hasRole ?> required type="text" class="form-control <?php $__errorArgs = ['disiplin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Disiplin">
                  <?php $__errorArgs = ['disiplin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>Kerapihan</label>
                  <input wire:model.defer="state.rapih" <?php if (app('laratrust')->hasRole('siswa|orang_tua')) : ?> readonly <?php endif; // app('laratrust')->hasRole ?> required type="text" class="form-control <?php $__errorArgs = ['rapih'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Kerapihan">
                  <?php $__errorArgs = ['rapih'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-3">
                <div class="form-group">
                  <label>Sakit</label>
                    <div class="input-group">
                        <input wire:model.defer="state.sakit_pesantren" <?php if (app('laratrust')->hasRole('siswa|orang_tua')) : ?> readonly <?php endif; // app('laratrust')->hasRole ?> type="number" class="form-control <?php $__errorArgs = ['sakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                    <?php $__errorArgs = ['sakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Izin</label>
                    <div class="input-group">
                        <input wire:model.defer="state.izin_pesantren" <?php if (app('laratrust')->hasRole('siswa|orang_tua')) : ?> readonly <?php endif; // app('laratrust')->hasRole ?> type="number" class="form-control <?php $__errorArgs = ['izin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                    <?php $__errorArgs = ['izin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Tanpa Keterangan</label>
                    <div class="input-group">
                        <input wire:model.defer="state.alpa_pesantren" <?php if (app('laratrust')->hasRole('siswa|orang_tua')) : ?> readonly <?php endif; // app('laratrust')->hasRole ?> type="number" class="form-control <?php $__errorArgs = ['alpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                    <?php $__errorArgs = ['alpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Jumlah</label>
                    <div class="input-group">
                        <input wire:model.defer="state.jumlah_pesantren" type="number" class="form-control" readonly/>
                        <div class="input-group-append">
                            <div class="input-group-text">Hari</div>
                        </div>
                    </div>
                </div>
              </div>
            </div>
            
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
            <?php if (app('laratrust')->hasRole('wali_kelas|superadmin')) : ?>
            <button type="submit" class="btn btn-success">Simpan</button>
            <?php endif; // app('laratrust')->hasRole ?>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->

  <!-- Modal Kelulusan -->
  <div class="modal fade" id="modal-kelulusan" wire:ignore.self>
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-success">
          <h4 class="modal-title">Form Kelulusan</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form wire:submit.prevent="updateKelulusan">
          <div class="modal-body">
            <div class="form-group">
              <label for="ket_naik">Keterangan Kelulusan</label>
              <select wire:model.defer="state.ket_naik" required class="form-control <?php $__errorArgs = ['ket_naik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ket_naik">
                <option value="">--Pilih--</option>
                <option value="Naik">Naik</option>
                <option value="Tidak Naik">Tidak Naik</option>
              </select>
              <?php $__errorArgs = ['ket_naik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
              <label for="ke_kelas">Ke Kelas</label>
              <select wire:model.defer="state.ke_kelas" class="form-control <?php $__errorArgs = ['ke_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                  <option value="">--Pilih--</option>
                  <option value="X">X</option>
                  <option value="XI">XI</option>
                  <option value="XII">XII</option>
              </select>
              <?php $__errorArgs = ['ke_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
            <button type="submit" class="btn btn-success">Simpan</button>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->

  <!-- Modal Catatan Ortu -->
  <div class="modal fade" id="modal-catatan-ortu" wire:ignore.self>
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header bg-danger">
          <h4 class="modal-title">Form Catatan Orang Tua</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form wire:submit.prevent="updateCatatanOrtu">
          <div class="modal-body">
            <div class="form-group">
              <label for="catatan_ortu">Catatan Orang Tua</label>
              <textarea wire:model.defer="state.catatan_ortu" <?php if (app('laratrust')->hasRole('siswa|wali_kelas')) : ?> readonly <?php endif; // app('laratrust')->hasRole ?> required class="form-control <?php $__errorArgs = ['catatan_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="catatan_ortu" placeholder="Catatan Orang Tua"></textarea>
              <?php $__errorArgs = ['catatan_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
            <?php if (app('laratrust')->hasRole('superadmin|orang_tua')) : ?>
            <button type="submit" class="btn btn-danger">Simpan</button>
            <?php endif; // app('laratrust')->hasRole ?>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->

  <!-- Modal Delete Data -->
  <div class="modal fade" id="modal-delete" wire:ignore.self>
      <div class="modal-dialog">
          <div class="modal-content bg-danger">
          <div class="modal-header">
              <h4 class="modal-title">Hapus Data</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
              </button>
          </div>
              <div class="modal-body">
                  <h5>Yakin ingin hapus data ?</h5>
              </div>
              <div class="modal-footer justify-content-between">
                  <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Tutup</button>
                  <button wire:click.prevent="deleteData" type="button" class="btn btn-outline-light">Lanjut Hapus</button>
              </div>
          </div>
          <!-- /.modal-content -->
      </div>
  <!-- /.modal-dialog -->
  </div>

  <?php $__env->startPush('style'); ?>
  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
  <?php $__env->stopPush(); ?>
  
  <?php $__env->startPush('script'); ?>
    <!-- SweetAlert2 -->
    <script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <!-- Sweet alert real rashid -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script>
      $(function () {
  
        window.addEventListener('show-form-delete', event => {
            $('#modal-delete').modal('show');
        });
  
        window.addEventListener('hide-form-delete', event => {
            $('#modal-delete').modal('hide');
  
            Swal.fire({
                "title":"Sukses!",
                "text":"Data Berhasil Dihapus",
                "position":"middle-center",
                "timer":2000,
                "width":"32rem",
                "heightAuto":true,
                "padding":"1.25rem",
                "showConfirmButton":false,
                "showCloseButton":false,
                "icon":"success"
            });
  
        });
  
        window.addEventListener('show-form-edit', event => {
            $('#modal-edit').modal('show');
        });

        window.addEventListener('show-form-lihat', event => {
            $('#modal-lihat').modal('show');
        });

        window.addEventListener('show-form-catatan-pesantren', event => {
            $('#modal-catatan-pesantren').modal('show');
        });

        window.addEventListener('show-form-catatan-ortu', event => {
            $('#modal-catatan-ortu').modal('show');
        });

        window.addEventListener('show-form-kelulusan', event => {
            $('#modal-kelulusan').modal('show');
        });

        window.addEventListener('hide-form-kelulusan', event => {
            $('#modal-kelulusan').modal('hide');
  
            Swal.fire({
                "title":"Sukses!",
                "text":"Keterangan Lulus Berhasil Disimpan",
                "position":"middle-center",
                "timer":2000,
                "width":"32rem",
                "heightAuto":true,
                "padding":"1.25rem",
                "showConfirmButton":false,
                "showCloseButton":false,
                "icon":"success"
            });
  
        });

        window.addEventListener('hide-form-catatan-pesantren', event => {
            $('#modal-catatan-pesantren').modal('hide');
  
            Swal.fire({
                "title":"Sukses!",
                "text":"Data Catatan Berhasil Disimpan",
                "position":"middle-center",
                "timer":2000,
                "width":"32rem",
                "heightAuto":true,
                "padding":"1.25rem",
                "showConfirmButton":false,
                "showCloseButton":false,
                "icon":"success"
            });
  
        });

        window.addEventListener('hide-form-catatan-ortu', event => {
            $('#modal-catatan-ortu').modal('hide');
  
            Swal.fire({
                "title":"Sukses!",
                "text":"Data Catatan Berhasil Disimpan",
                "position":"middle-center",
                "timer":2000,
                "width":"32rem",
                "heightAuto":true,
                "padding":"1.25rem",
                "showConfirmButton":false,
                "showCloseButton":false,
                "icon":"success"
            });
  
        });
  
        window.addEventListener('hide-form-edit', event => {
            $('#modal-edit').modal('hide');
  
            Swal.fire({
                "title":"Sukses!",
                "text":"Data Berhasil Diedit",
                "position":"middle-center",
                "timer":2000,
                "width":"32rem",
                "heightAuto":true,
                "padding":"1.25rem",
                "showConfirmButton":false,
                "showCloseButton":false,
                "icon":"success"
            });
  
        });
  
        window.addEventListener('show-form', event => {
            $('#form').modal('show');
        });
  
        window.addEventListener('hide-form', event => {
            $('#form').modal('hide');
  
            Swal.fire({
                "title":"Sukses!",
                "text":"Data Berhasil Ditambahkan",
                "position":"middle-center",
                "timer":2000,
                "width":"32rem",
                "heightAuto":true,
                "padding":"1.25rem",
                "showConfirmButton":false,
                "showCloseButton":false,
                "icon":"success"
            });
  
        });
  
      });
    </script>
    
    <?php $__env->stopPush(); ?>

</div><?php /**PATH C:\Users\ASUS\Documents\Aplikasi\laravel-rapor-smk\resources\views/livewire/rapor-data.blade.php ENDPATH**/ ?>