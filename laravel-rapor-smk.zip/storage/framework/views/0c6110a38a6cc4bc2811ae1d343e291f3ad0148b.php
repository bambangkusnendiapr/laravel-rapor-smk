<?php $__env->startSection('title', 'Rapor Pesantren'); ?>
<?php $__env->startSection('nilai-rapor', 'menu-open'); ?>
<?php $__env->startSection('nilai_rapor', 'active'); ?>
<?php $__env->startSection('rapor', 'active'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'layouts.admin.main','data' => []]); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <div>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Rapor Pesantren</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Admin</a></li>
              <li class="breadcrumb-item"><a href="#">Penilaian Rapor</a></li>
              <li class="breadcrumb-item"><a href="<?php echo e(route('rapor')); ?>">Nilai Rapor</a></li>
              <li class="breadcrumb-item active">Rapor Pesantren</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <a href="<?php echo e(route('rapor')); ?>" class="btn btn-dark"><i class="fas fa-long-arrow-alt-left"></i> Kembali</a>
                <a href="<?php echo e(route('rapor.pesantren.print', $rapor->id)); ?>" target="_blank" class="btn btn-secondary"><i class="fas fa-file-download"></i> Print / PDF</a>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <span>Siswa: </span><label><?php echo e($rapor->student->user->name); ?></label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <span>Semester: </span><label><?php echo e($rapor->semester->nama); ?> - <?php echo e($rapor->semester->tahun); ?></label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <span>Kelas: </span><label><?php echo e($rapor->kelas); ?> - <?php echo e($rapor->student->major->jurusan); ?></label>
                        </div>
                    </div>
                </div>

                <div class="table-responsive-sm">
                  <table class="table table-sm table-bordered table-striped mt-1">
                    <thead>
                      <tr class="text-center">
                          <th rowspan="2" class="align-middle">#</th>
                          <th rowspan="2" class="align-middle">Komponen</th>
                          <th rowspan="2" class="align-middle">KKM</th>
                          <th colspan="3">Nilai</th>
                          <th rowspan="2" class="align-middle">Ketuntasan</th>
                      </tr>
                      <tr>
                          <th>Angka</th>
                          <th>Huruf</th>
                          <th>Predikat</th>
                      </tr>
                      <tr>
                        <th colspan="3">Mata Pelajaran</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($data->nama); ?></td>
                        <?php $__empty_1 = true; $__currentLoopData = $nilai->where('lesson_id', $data->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <td><?php echo e($value->kkm); ?></td>
                        <td><?php echo e($value->nilai); ?></td>
                        <td><?php echo e($value->huruf); ?></td>
                        <td><?php echo e($value->predikat); ?></td>
                        <td><?php echo e($value->tuntas); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <?php endif; ?>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                      <tr>
                        <th colspan="2">Jumlah</th>
                        <th></th>
                        <th><?php echo e($nilai->sum('nilai')); ?></th>
                        <th></th>
                        <th></th>
                        <th></th>
                      </tr>
                      <tr>
                        <td colspan="2">Peringkat Ke</td>
                        <td></td>
                        <td colspan="4"></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

              </div>
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\ASUS\Documents\Aplikasi\laravel-rapor-smk\resources\views/admin/rapor_pesantren/index.blade.php ENDPATH**/ ?>